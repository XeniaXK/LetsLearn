package com.example.yohannallenzia.heylearn;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.google.android.youtube.player.YouTubeBaseActivity;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerView;

import java.util.ArrayList;
import java.util.List;

public class YoutubeActivity extends YouTubeBaseActivity {

    private static final String TAG="YoutubeActivity";
    YouTubePlayerView myPlayer;
    YouTubePlayer.OnInitializedListener myListener;
    List<String> videoList = new ArrayList<>(  );

    static final String GOOGLE_API_KEY = "AIzaSyBjEW8XtXhD5DIaiOv_JZkDkwOcRuZ4IH4";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_youtube );

        myPlayer = (YouTubePlayerView) findViewById( R.id.youtubePlayer );
        Intent intent = getIntent();
        String methodology = intent.getStringExtra( "methodology" );
        int position = intent.getExtras().getInt( "position" );


        Log.d( TAG, "Youtube: " + methodology + " " + position);

        if(methodology.equals( "agile" )){
            if(position ==  0){
                videoList.add( "9TycLR0TqFA" );
                videoList.add( "" );
            } else if(position == 1){
                videoList.add( "KLARQSoNAlc" );
                videoList.add( "" );
            } else if(position ==  2){
                videoList.add( "EDT0HMtDwYI" );
                videoList.add( "" );
            }
        } else if(methodology.equals( "lean" )){
            if(position ==  0){
                videoList.add( "20xuu_8wWnY" );
                videoList.add( "" );
            } else if(position == 1){
                videoList.add( "yZvsqm4Jok8" );
                videoList.add( "" );
            } else if(position ==  2){
                videoList.add( "wfsRAZUnonI" );
                videoList.add( "" );
            }} else {
            if(position ==  0){
                videoList.add( "0V5BwTrQOCs" );
                videoList.add( "" );
            } else if(position == 1){
                videoList.add( "_r0VX-aU_T8" );
                videoList.add( "" );
            } else if(position ==  2){
                videoList.add( "psLjEBUOnVs" );
                videoList.add( "" );}}

        myListener = new YouTubePlayer.OnInitializedListener() {
            @Override
            public void onInitializationSuccess(YouTubePlayer.Provider provider, YouTubePlayer youTubePlayer, boolean b) {


                youTubePlayer.loadVideos( videoList );

                Log.d( TAG, "onInitializationSuccess: yay" );

            }

            @Override
            public void onInitializationFailure(YouTubePlayer.Provider provider, YouTubeInitializationResult youTubeInitializationResult) {
                Log.d( TAG, "onInitializationFailure: nooo" );
            }
        };

        myPlayer.initialize( GOOGLE_API_KEY, myListener );

    }
}
