//package com.example.yohannallenzia.heylearn;
//
//import android.content.Intent;
//import android.support.v7.app.AppCompatActivity;
//import android.os.Bundle;
//import android.util.Log;
//import android.view.Menu;
//import android.view.View;
//import android.widget.Button;
//import android.widget.RadioButton;
//import android.widget.RadioGroup;
//import android.widget.TextView;
//
//import java.util.List;
//
//public class QuizActivity extends AppCompatActivity {
//    List<Questions> quesList;
//    int score=0;
//    int qid=0;
//    Questions currentQ;
//    TextView txtQuestion;
//    RadioButton rda, rdb, rdc;
//    Button butNext;
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_quiz);
//        MyDatabase db=new MyDatabase(this);
//        quesList=db.getAllQuestions();
//        currentQ=quesList.get(qid);
//        txtQuestion=(TextView)findViewById(R.id.questionNo);
//        rda=(RadioButton)findViewById(R.id.radioButton);
//        rdb=(RadioButton)findViewById(R.id.radioButton2);
//        rdc=(RadioButton)findViewById(R.id.radioButton3);
//        butNext=(Button)findViewById(R.id.nextButton);
//        setQuestionView();
//        butNext.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                RadioGroup grp=(RadioGroup)findViewById(R.id.radioGroup);
//                RadioButton answer=(RadioButton)findViewById(grp.getCheckedRadioButtonId());
//                grp.clearCheck();
//                Log.d("yourans", currentQ.getANSWER()+" "+answer.getText());
//                if(currentQ.getANSWER().equals(answer.getText()))
//                {
//                    score++;
//                    Log.d("score", "Your score"+score);
//                }
//                if(qid<5){
//                    currentQ=quesList.get(qid);
//                    setQuestionView();
//                }else{
//                    /*
//                    Intent intent = new Intent(QuizActivity.this, ResultActivity.class);
//                    Bundle b = new Bundle();
//                    b.putInt("score", score); //Your score
//                    intent.putExtras(b); //Put your score to your next Intent
//                    startActivity(intent);
//                    finish();
//                    */
//                }
//            }
//        });
//    }
//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        // Inflate the menu; this adds items to the action bar if it is present.
//      //  getMenuInflater().inflate(R.menu.activity_quiz, menu);
//        return true;
//    }
//    private void setQuestionView()
//    {
//        txtQuestion.setText(currentQ.getQUESTION());
//        rda.setText(currentQ.getOPTA());
//        rdb.setText(currentQ.getOPTB());
//        rdc.setText(currentQ.getOPTC());
//        qid++;
//    }
//}
