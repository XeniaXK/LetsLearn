package com.example.yohannallenzia.heylearn;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class QuizFragment extends Fragment {

    List<Questions> quesList;
    int score=0;
    int qid=0;
    Questions currentQ;
    TextView txtQuestion;
    RadioButton rda, rdb, rdc;
    Button butNext;

    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        final View myView=inflater.inflate( R.layout.activity_quiz, container, false );

        MyDatabase db=new MyDatabase( getContext() );
        quesList=db.getAllQuestions();
        currentQ=quesList.get( qid );
        txtQuestion=(TextView) myView.findViewById( R.id.questionNo );
        rda=(RadioButton) myView.findViewById( R.id.radioButton );
        rdb=(RadioButton) myView.findViewById( R.id.radioButton2 );
        rdc=(RadioButton) myView.findViewById( R.id.radioButton3 );
        butNext=(Button) myView.findViewById( R.id.nextButton );
        setQuestionView();
        butNext.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RadioGroup grp=(RadioGroup) myView.findViewById( R.id.radioGroup );
                RadioButton answer=(RadioButton) myView.findViewById( grp.getCheckedRadioButtonId() );
                grp.clearCheck();
                Log.d( "yourans", currentQ.getANSWER()+" "+answer.getText() );
                if(currentQ.getANSWER().equals( answer.getText() )) {
                    score++;
                    Log.d( "score", "Your score"+score );
                }
                if(qid<5) {
                    currentQ=quesList.get( qid );
                    setQuestionView();
                } else {
                    /*
                    Intent intent = new Intent(QuizActivity.this, ResultActivity.class);
                    Bundle b = new Bundle();
                    b.putInt("score", score); //Your score
                    intent.putExtras(b); //Put your score to your next Intent
                    startActivity(intent);
                    finish();
                    */
                }
            }
        } );

        return myView;
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        //  getMenuInflater().inflate(R.menu.activity_quiz, menu);
        return true;
    }

    private void setQuestionView() {
        txtQuestion.setText( currentQ.getQUESTION() );
        rda.setText( currentQ.getOPTA() );
        rdb.setText( currentQ.getOPTB() );
        rdc.setText( currentQ.getOPTC() );
        qid++;
    }
}

