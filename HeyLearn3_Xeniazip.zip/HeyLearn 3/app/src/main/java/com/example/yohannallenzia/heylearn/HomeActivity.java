package com.example.yohannallenzia.heylearn;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        final Button agileButton = (Button) findViewById(R.id.agileButton);
        final Button leanButton = (Button) findViewById(R.id.leanButton);
        final Button designButton = (Button) findViewById(R.id.designButton);
        final Button emailButton = (Button) findViewById(R.id.emailButton);

        View.OnClickListener buttonListener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Button x = (Button) view;

                if (x == agileButton){
                    Intent intent = new Intent(HomeActivity.this, BaseActivity.class);
                    intent.putExtra("methodology", "agile");
                    startActivity(intent);
                } else if(x == leanButton){
                    Intent intent1 = new Intent(HomeActivity.this, BaseActivity.class);
                    intent1.putExtra("methodology", "lean");
                    startActivity(intent1);
                } else if (x == designButton) {
                    Intent intent2 = new Intent(HomeActivity.this, BaseActivity.class);
                    intent2.putExtra("methodology", "design");
                    startActivity(intent2);
                }
                else {
                    Intent intent3 = new Intent(HomeActivity.this, Email.class);
                    startActivity(intent3);
                }
            }
        };

        agileButton.setOnClickListener(buttonListener);
        leanButton.setOnClickListener(buttonListener);
        designButton.setOnClickListener(buttonListener);
        emailButton.setOnClickListener(buttonListener);
    }
}
